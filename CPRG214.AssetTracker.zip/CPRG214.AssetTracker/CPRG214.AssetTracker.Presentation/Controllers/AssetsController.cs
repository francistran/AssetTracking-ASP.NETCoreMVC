﻿using System.Collections;
using System.Linq;
using CPRG214.AssetTracker.BLL;
using CPRG214.AssetTracker.Domain;
using CPRG214.AssetTracker.Presentation.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace CPRG214.AssetTracker.Presentation.Controllers
{
    public class AssetsController : Controller
    {
        public IActionResult Index()
        {
            var assets = AssetManager.GetAll();
            var viewModels = assets.Select(a => new AssetViewModel
            {
                Id = a.Id,
                TagNumber = a.TagNumber,
                Manufacturer = a.Manufacturer,
                Model = a.Model,
                Description = a.Description,
                SerialNumber = a.SerialNumber,
                AssetType = a.AssetType.Name
            }).ToList();
            return View(viewModels);            
        }

        public IActionResult GetAssetsByType(int id)
        {

            return ViewComponent("AssetsByType", id);
        }

        public IActionResult Search()
        {
            ViewBag.AssetTypes = GetAssetTypes();
            return View();
        }        

        public IActionResult Create()
        {
            ViewBag.AssetTypeId = GetAssetTypesForCreate();
            return View();
        }
        [HttpPost]
        public IActionResult Create(Asset asset)
        {
            try
            {
                AssetManager.Add(asset);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }            
        }

        protected IEnumerable GetAssetTypesForCreate()
        {
            var types = AssetTypeManager.GetAsKeyValuePairs();
            var list = new SelectList(types, "Value", "Text");
            return list;
        }

        protected IEnumerable GetAssetTypes()
        {
            var types = AssetTypeManager.GetAsKeyValuePairs();
            var list = new SelectList(types, "Value", "Text");

            var list2 = list.ToList();
            list2.Insert(0, new SelectListItem
            {
                Text = "All Types",
                Value = "0"
            });
            return list2;
        }


        // GET: Asset/Edit
        public IActionResult Edit(int id)
        {
            var asset = AssetManager.Find(id);
            ViewBag.AssetTypeId = GetAssetTypesForCreate();
            return View(asset);
        }

        // POST: AssetType/Edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Asset asset)
        {
            try
            {
                //call the AssetManager to edit

                AssetManager.Update(asset);

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

    }
}