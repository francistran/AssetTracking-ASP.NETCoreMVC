﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CPRG214.AssetTracker.BLL;
using CPRG214.AssetTracker.Domain;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CPRG214.AssetTracker.Presentation.Controllers
{
    public class AssetTypeController : Controller
    {
        // GET: AssetType
        public ActionResult Index()
        {
            var assettypes = AssetTypeManager.GetAll();
            return View(assettypes);
        }

        // GET: AssetType/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: AssetType/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(AssetType assettype)
        {
            try
            {
                AssetTypeManager.Add(assettype);

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: AssetType/Edit/5
        public ActionResult Edit(int id)
        {
            var assettype = AssetTypeManager.Find(id);
            return View(assettype);
        }

        // POST: AssetType/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(AssetType assettype)
        {
            try
            {
                AssetTypeManager.Update(assettype);

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

    }
}