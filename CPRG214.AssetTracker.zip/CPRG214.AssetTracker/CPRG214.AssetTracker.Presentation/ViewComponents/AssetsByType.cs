﻿using CPRG214.AssetTracker.BLL;
using CPRG214.AssetTracker.Domain;
using CPRG214.AssetTracker.Presentation.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CPRG214.AssetTracker.Presentation.ViewComponents
{
    public class AssetsByTypeViewComponent : ViewComponent
    {
        public async Task<IViewComponentResult> InvokeAsync(int id)
        {
            List<Asset> assets = null;

            if(id == 0)
            {
                assets = AssetManager.GetAll();
            }
            else
            {
                assets = AssetManager.GetAllByAssetType(id);
            }
            
            var tracks = assets.Select(a => new AssetViewModel
            {
                Id = a.Id,
                TagNumber = a.TagNumber,
                Manufacturer = a.Manufacturer,
                Model = a.Model,
                Description = a.Description,
                SerialNumber = a.SerialNumber,
                AssetType = a.AssetType.Name                            
            }).ToList();

            return View(tracks);
        }
    }
}
