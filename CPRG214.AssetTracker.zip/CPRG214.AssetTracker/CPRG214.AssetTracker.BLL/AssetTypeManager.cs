﻿using CPRG214.AssetTracker.Data;
using System.Collections;
using System.Linq;
using System.Collections.Generic;
using CPRG214.AssetTracker.Domain;

namespace CPRG214.AssetTracker.BLL
{
    public class AssetTypeManager
    {
        public static List<AssetType> GetAll()
        {
            var context = new AssetContext();
            var assettypes = context.AssetTypes.OrderBy(at => at.Name).ToList();
            return assettypes;
        }

        public static void Add(AssetType assettype)
        {
            var context = new AssetContext();
            context.AssetTypes.Add(assettype);
            context.SaveChanges();
        }

        public static void Update(AssetType assettype)
        {
            var context = new AssetContext();
            var originalAssetType = context.AssetTypes.Find(assettype.Id);
            originalAssetType.Name = assettype.Name;
            context.SaveChanges();
        }

        public static AssetType Find(int id)
        {
            var context = new AssetContext();
            var assettype = context.AssetTypes.Find(id);
            return assettype;
        }

        public static IList GetAsKeyValuePairs()
        {
            var context = new AssetContext();
            var types = context.AssetTypes.Select(type => new
            {
                Value = type.Id,
                Text = type.Name
            }).ToList();
            return types;
        }
    }
}
