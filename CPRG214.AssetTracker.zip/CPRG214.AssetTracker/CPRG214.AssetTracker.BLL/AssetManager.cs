﻿using CPRG214.AssetTracker.Data;
using CPRG214.AssetTracker.Domain;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Collections;

namespace CPRG214.AssetTracker.BLL
{
    public class AssetManager
    {
        public static List<Asset> GetAll()
        {
            var context = new AssetContext();
            var asset = context.Assets.Include(t => t.AssetType).ToList();
            return asset;
        }

        public static List<Asset> GetAllByAssetType(int id)
        {
            var context = new AssetContext();
            var asset = context.Assets.
                Where(prop => prop.AssetTypeId == id).
                Include(t => t.AssetType).ToList();
            return asset;
        }

        public static void Add(Asset asset)
        {
            var context = new AssetContext();
            context.Assets.Add(asset);
            context.SaveChanges();
        }

        //
        public static void Update(Asset asset)
        {
            var context = new AssetContext();
            var originalAsset = context.Assets.Find(asset.Id);
            originalAsset.TagNumber = asset.TagNumber;
            originalAsset.Manufacturer = asset.Manufacturer;
            originalAsset.Model = asset.Model;
            originalAsset.Description = asset.Description;
            originalAsset.SerialNumber = asset.SerialNumber;
            originalAsset.AssetTypeId = asset.AssetTypeId;            

            context.SaveChanges();
        }

        public static Asset Find(int id)
        {
            var context = new AssetContext();
            var asset = context.Assets.Find(id);
            return asset;
        }
    }
}
