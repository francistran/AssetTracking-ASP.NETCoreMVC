﻿using CPRG214.AssetTracker.Domain;
using Microsoft.EntityFrameworkCore;
using System;

namespace CPRG214.AssetTracker.Data
{
    public class AssetContext : DbContext
    {
        public AssetContext() : base() { }
        public DbSet<Asset> Assets { get; set; }
        public DbSet<AssetType> AssetTypes { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //Change the connection string here for your computer
            optionsBuilder.UseSqlServer(@"Server=.\SQLEXPRESS;Database=AssetTracker;Trusted_Connection=True;");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            //seed data created here
            modelBuilder.Entity<AssetType>().HasData(
            new AssetType { Id = 1, Name = "Desktop computer" },
            new AssetType { Id = 2, Name = "Computer monitor" },
            new AssetType { Id = 3, Name = "Phones" }
            );

            modelBuilder.Entity<Asset>().HasData(
            new Asset
            {
                Id = 1,
                TagNumber = "D123",
                Manufacturer = "Dell",
                Model = "Tower case",
                Description = "Big desktop",
                SerialNumber = "D123-101",
                AssetTypeId = 1
            },
            new Asset
            {
                Id = 2,
                TagNumber = "M456",
                Manufacturer = "Acer",
                Model = "Wide screen",
                Description = "Large size monitor",
                SerialNumber = "M456-201",
                AssetTypeId = 2
            },
            new Asset
            {
                Id = 3,
                TagNumber = "P789",
                Manufacturer = "Avaya",
                Model = "Black",
                Description = "Black phone",
                SerialNumber = "P789-301",
                AssetTypeId = 3
            }
            );
        }
    }
}